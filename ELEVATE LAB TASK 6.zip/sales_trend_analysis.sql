-- Task 6: Sales Trend Analysis Using Aggregations
-- SQL Dialect: PostgreSQL
-- Dataset columns: order_id, order_date, amount, product_id

-- =========================================================
-- A. Create table
-- =========================================================
DROP TABLE IF EXISTS online_sales;

CREATE TABLE online_sales (
    order_id    INT PRIMARY KEY,
    order_date  DATE NOT NULL,
    amount      NUMERIC(10,2),
    product_id  VARCHAR(20)
);

-- =========================================================
-- B. Import the CSV
-- =========================================================
-- In pgAdmin:
-- 1. Right-click online_sales -> Import/Export Data
-- 2. Select online_sales.csv
-- 3. Format: CSV, Header: Yes
-- 4. Import
--
-- Or use psql after replacing the path:
-- \copy online_sales(order_id, order_date, amount, product_id)
-- FROM 'online_sales.csv'
-- WITH (FORMAT csv, HEADER true);

-- =========================================================
-- C. Main query: monthly revenue + order volume
-- =========================================================
SELECT
    EXTRACT(YEAR FROM order_date) AS year,
    EXTRACT(MONTH FROM order_date) AS month,
    ROUND(SUM(amount), 2) AS monthly_revenue,
    COUNT(DISTINCT order_id) AS order_volume
FROM online_sales
GROUP BY
    EXTRACT(YEAR FROM order_date),
    EXTRACT(MONTH FROM order_date)
ORDER BY
    year,
    month;

-- =========================================================
-- D. Limit to a specific time period
-- Example: only 2025
-- =========================================================
SELECT
    EXTRACT(YEAR FROM order_date) AS year,
    EXTRACT(MONTH FROM order_date) AS month,
    ROUND(SUM(amount), 2) AS monthly_revenue,
    COUNT(DISTINCT order_id) AS order_volume
FROM online_sales
WHERE order_date >= DATE '2025-01-01'
  AND order_date <  DATE '2026-01-01'
GROUP BY
    EXTRACT(YEAR FROM order_date),
    EXTRACT(MONTH FROM order_date)
ORDER BY
    year,
    month;

-- =========================================================
-- E. Top 3 months by sales
-- =========================================================
SELECT
    EXTRACT(YEAR FROM order_date) AS year,
    EXTRACT(MONTH FROM order_date) AS month,
    ROUND(SUM(amount), 2) AS monthly_revenue,
    COUNT(DISTINCT order_id) AS order_volume
FROM online_sales
GROUP BY
    EXTRACT(YEAR FROM order_date),
    EXTRACT(MONTH FROM order_date)
ORDER BY
    monthly_revenue DESC
LIMIT 3;

-- =========================================================
-- F. Optional: month label for a cleaner report
-- =========================================================
SELECT
    TO_CHAR(DATE_TRUNC('month', order_date), 'YYYY-MM') AS sales_month,
    ROUND(SUM(amount), 2) AS monthly_revenue,
    COUNT(DISTINCT order_id) AS order_volume
FROM online_sales
GROUP BY DATE_TRUNC('month', order_date)
ORDER BY DATE_TRUNC('month', order_date);
